#!/usr/bin/ruby

puts "Meep meep!"
